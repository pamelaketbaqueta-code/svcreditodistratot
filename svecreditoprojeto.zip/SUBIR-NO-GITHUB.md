# Subir ao GitHub e publicar

O projeto já vem com Git inicializado e o primeiro commit feito.

## 1. Criar o repositório
github.com/new → nome `metrocasa` → deixe vazio (sem README) → Create.

## 2. Enviar (troque SEU-USUARIO)
```bash
git remote add origin https://github.com/SEU-USUARIO/metrocasa.git
git branch -M main
git push -u origin main
```
No push, use um token no lugar da senha (GitHub → Settings → Developer settings → Personal access tokens).

## 3. Publicar na Vercel
vercel.com → entre com o GitHub → Add New → Project → escolha `metrocasa` → Deploy.
A Vercel detecta o Vite sozinho. Cada `git push` atualiza o site.

## 4. Ligar o Google Sheets e a IA
Em Settings → Environment Variables da Vercel:
- `VITE_API_URL` e `VITE_API_TOKEN` (veja api/INSTALAR-BACKEND.md)
- `ANTHROPIC_API_KEY` (opcional, para a IA)
Depois, Redeploy.

Sem variáveis, o sistema já funciona em modo demonstração.
