import React from "react";
import { CORES } from "../lib/defs";

export const S = {
  input: (dark) => ({ width: "100%", padding: "8px 10px", border: `1px solid ${dark ? "#3A4452" : "#D5DBE3"}`, borderRadius: 6, fontSize: 13, background: dark ? "#222B36" : "#fff", color: dark ? "#E8ECF1" : "#1B2733", outline: "none", boxSizing: "border-box" }),
  label: (dark) => ({ fontSize: 11, fontWeight: 600, color: dark ? "#9AA7B6" : "#5B6B7C", textTransform: "uppercase", letterSpacing: 0.4, display: "block", marginBottom: 4 }),
  btn: (v = "primary") => ({ padding: "8px 14px", borderRadius: 6, fontSize: 13, fontWeight: 600, cursor: "pointer", border: v === "ghost" ? "1px solid #D5DBE3" : "none", background: v === "primary" ? CORES.primary : v === "danger" ? "#B03A3A" : v === "ok" ? "#2E8B57" : "#fff", color: v === "ghost" ? "#1B2733" : "#fff", fontFamily: "inherit" }),
  card: (dark) => ({ background: dark ? "#1A222C" : "#fff", border: `1px solid ${dark ? "#2A3340" : "#E2E7EE"}`, borderRadius: 10 }),
};

export function Card({ dark, titulo, valor, cor, sub }) {
  return (
    <div style={{ ...S.card(dark), padding: "14px 16px", minWidth: 120, flex: 1 }}>
      <div style={{ fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.5, color: dark ? "#9AA7B6" : "#5B6B7C" }}>{titulo}</div>
      <div style={{ fontSize: 26, fontWeight: 800, color: cor || (dark ? "#E8ECF1" : "#1B2733"), marginTop: 4 }}>{valor}</div>
      {sub && <div style={{ fontSize: 11, color: "#8B99A9", marginTop: 2 }}>{sub}</div>}
    </div>
  );
}

export function Barras({ dark, dados, max }) {
  const m = max || Math.max(1, ...dados.map((d) => d.valor));
  return (
    <div>
      {dados.map((d, i) => (
        <div key={i} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 7 }}>
          <span style={{ width: 130, fontSize: 11.5, color: dark ? "#9AA7B6" : "#5B6B7C", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{d.nome}</span>
          <div style={{ flex: 1, height: 14, background: dark ? "#222B36" : "#F0F2F6", borderRadius: 4 }}>
            <div style={{ width: `${(d.valor / m) * 100}%`, height: "100%", background: d.cor || CORES.primary, borderRadius: 4, minWidth: d.valor ? 4 : 0 }} />
          </div>
          <span style={{ width: 30, fontSize: 12, fontWeight: 700, textAlign: "right", color: dark ? "#E8ECF1" : "#1B2733" }}>{d.valor}</span>
        </div>
      ))}
      {dados.length === 0 && <div style={{ fontSize: 12.5, color: "#8B99A9" }}>Sem dados.</div>}
    </div>
  );
}

export function Drawer({ children, fechar, largura = 600 }) {
  return (
    <div onClick={fechar} style={{ position: "fixed", inset: 0, background: "rgba(15,23,33,.45)", zIndex: 50, display: "flex", justifyContent: "flex-end" }}>
      <div onClick={(e) => e.stopPropagation()} style={{ width: `min(${largura}px,100vw)`, background: "#fff", height: "100%", overflowY: "auto", boxShadow: "-6px 0 24px rgba(0,0,0,.2)" }}>
        {children}
      </div>
    </div>
  );
}

export function Vazio({ texto, dark }) {
  return <div style={{ ...S.card(dark), borderStyle: "dashed", padding: 36, textAlign: "center", color: "#8B99A9", fontSize: 14 }}>{texto}</div>;
}
