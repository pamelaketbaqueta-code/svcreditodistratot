import React, { useState } from "react";
import { api } from "../lib/api";
import { CORES, PERFIS, PERFIL_NOME } from "../lib/defs";
import { usuariosDemo } from "../lib/seed";
import { S } from "../components/ui";
import ConexaoSheets from "./ConexaoSheets";
import ImportarSheets from "./ImportarSheets";

export default function Login({ onEntrar }) {
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [erro, setErro] = useState("");
  const [carregando, setCarregando] = useState(false);
  const [mostrarConexao, setMostrarConexao] = useState(false);
  const demo = api.modo === "demo";

  const entrar = async () => {
    setErro(""); setCarregando(true);
    try {
      const r = await api.login(email, senha);
      if (!r.ok) { setErro(r.error || "Não foi possível entrar"); setCarregando(false); return; }
      if (!PERFIS.includes(r.usuario.perfil)) { setErro("Seu perfil não tem acesso ao sistema."); setCarregando(false); return; }
      onEntrar(r.usuario);
    } catch { setErro("Falha de conexão"); }
    setCarregando(false);
  };

  return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: CORES.cinza, fontFamily: "'Segoe UI',system-ui,sans-serif", padding: 16 }}>
      <div style={{ width: 380, background: "#fff", borderRadius: 14, boxShadow: "0 10px 40px rgba(0,0,0,.12)", overflow: "hidden" }}>
        <div style={{ background: CORES.primary, padding: "26px 24px", color: "#fff" }}>
          <div style={{ fontWeight: 800, fontSize: 22, letterSpacing: 1 }}>METROCASA</div>
          <div style={{ fontSize: 12.5, opacity: 0.9, marginTop: 2 }}>Gestão de Vendas e Contratos</div>
        </div>
        <div style={{ padding: 24 }}>
          <label style={S.label()}>E-mail</label>
          <input value={email} onChange={(e) => setEmail(e.target.value)} onKeyDown={(e) => e.key === "Enter" && entrar()} style={{ ...S.input(), marginBottom: 12 }} placeholder="seu@metrocasa.com" />
          <label style={S.label()}>Senha</label>
          <input type="password" value={senha} onChange={(e) => setSenha(e.target.value)} onKeyDown={(e) => e.key === "Enter" && entrar()} style={{ ...S.input(), marginBottom: 16 }} placeholder="••••••" />
          {erro && <div style={{ color: "#B03A3A", fontSize: 12.5, fontWeight: 600, marginBottom: 12 }}>{erro}</div>}
          <button onClick={entrar} disabled={carregando} style={{ ...S.btn(), width: "100%", padding: "10px", opacity: carregando ? 0.6 : 1 }}>{carregando ? "Entrando…" : "Entrar"}</button>

          {demo && (
            <div style={{ marginTop: 18, borderTop: "1px solid #EEF1F5", paddingTop: 14 }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: "#5B6B7C", textTransform: "uppercase", letterSpacing: 0.4, marginBottom: 8 }}>Entrar como (demonstração)</div>
              <div style={{ display: "grid", gap: 6, maxHeight: 230, overflowY: "auto" }}>
                {usuariosDemo().map((u) => (
                  <button key={u.id} onClick={() => onEntrar(u)} style={{ display: "flex", alignItems: "center", gap: 10, textAlign: "left", padding: "8px 10px", border: "1px solid #E2E7EE", borderRadius: 8, background: "#fff", cursor: "pointer", fontFamily: "inherit" }}>
                    <span style={{ width: 30, height: 30, borderRadius: "50%", background: CORES.primary, color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700, flexShrink: 0 }}>{(u.apelido || u.nome).slice(0, 2).toUpperCase()}</span>
                    <span style={{ minWidth: 0 }}>
                      <span style={{ fontSize: 13, fontWeight: 600, display: "block" }}>{u.nome}</span>
                      <span style={{ fontSize: 11, color: "#8B99A9" }}>{PERFIL_NOME[u.perfil]}</span>
                    </span>
                  </button>
                ))}
              </div>
              <div style={{ fontSize: 11, color: "#8B99A9", marginTop: 10, lineHeight: 1.5 }}>Cada perfil vê apenas as suas vendas (gerente), a equipe (superintendente/diretor) ou as atribuídas (analistas).</div>
            </div>
          )}

          <div style={{ marginTop: 16, textAlign: "center" }}>
            <button onClick={() => setMostrarConexao(!mostrarConexao)} style={{ background: "transparent", border: "none", color: CORES.primary, fontWeight: 600, fontSize: 12.5, cursor: "pointer", fontFamily: "inherit" }}>
              {mostrarConexao ? "▲ Ocultar conexão" : "⚙ Conectar banco de dados (Supabase / Sheets)"}
            </button>
          </div>
          {mostrarConexao && <div style={{ marginTop: 10, display: "grid", gap: 10 }}><ImportarSheets dark={false} compacto /><ConexaoSheets dark={false} compacto /></div>}
        </div>
      </div>
    </div>
  );
}
