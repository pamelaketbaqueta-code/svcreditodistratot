import React, { useState, useEffect, useRef, useMemo } from "react";
import { fmtData, iniciais, CORES } from "../lib/defs";
import { S, Vazio } from "../components/ui";

// mensagens não lidas PARA o usuário atual (escritas por outra pessoa)
export function naoLidasDe(db, usuario) {
  return (db.mensagens || []).filter((m) => m.autor !== usuario.nome && String(m.lida).toUpperCase() !== "SIM");
}

// quem é o "outro lado" da conversa, para preencher o campo "para"
function contraparte(venda, usuario) {
  const comercial = [venda.corretor, venda.gerente].filter(Boolean).join(" / ");
  const analise = [venda.analista_sv, venda.analista_credito].filter(Boolean).join(" / ");
  const souComercial = [venda.corretor, venda.gerente].includes(usuario.nome);
  return (souComercial ? analise : comercial) || (analise || comercial) || "responsável";
}

// ---------------------------------------------------------------
// Thread de uma venda — usada dentro do Detalhe da Venda e no Inbox
// ---------------------------------------------------------------
export function ChatThread({ db, usuario, venda, salvar, recarregar, dark, altura = 420 }) {
  const [texto, setTexto] = useState("");
  const [enviando, setEnviando] = useState(false);
  const fimRef = useRef(null);
  const marcadoRef = useRef("");

  const msgs = useMemo(
    () => (db.mensagens || []).filter((m) => m.venda_id === venda.id).sort((a, b) => new Date(a.criado_em) - new Date(b.criado_em)),
    [db.mensagens, venda.id]
  );

  // marca como lidas as mensagens recebidas ao abrir a conversa
  useEffect(() => {
    const naoLidas = msgs.filter((m) => m.autor !== usuario.nome && String(m.lida).toUpperCase() !== "SIM");
    const chave = venda.id + ":" + naoLidas.map((m) => m.id).join(",");
    if (naoLidas.length === 0 || marcadoRef.current === chave) return;
    marcadoRef.current = chave;
    (async () => {
      for (const m of naoLidas) await salvar("mensagens", { ...m, lida: "SIM" }, false);
      if (recarregar) await recarregar();
    })();
  }, [msgs, venda.id, usuario.nome]);

  useEffect(() => { fimRef.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs.length]);

  const enviar = async () => {
    const t = texto.trim();
    if (!t) return;
    setEnviando(true);
    await salvar("mensagens", {
      venda_id: venda.id,
      autor: usuario.nome,
      autor_papel: usuario.perfil,
      para: contraparte(venda, usuario),
      texto: t,
      lida: "NAO",
      criado_em: new Date().toISOString(),
    });
    setTexto("");
    setEnviando(false);
  };

  const bgThread = dark ? "#141C26" : "#F5F6F8";
  return (
    <div style={{ display: "flex", flexDirection: "column", height: altura, border: `1px solid ${dark ? "#2A3340" : "#E2E7EE"}`, borderRadius: 10, overflow: "hidden" }}>
      <div style={{ padding: "8px 12px", fontSize: 11.5, color: dark ? "#9AA7B6" : "#5B6B7C", background: dark ? "#1A222C" : "#fff", borderBottom: `1px solid ${dark ? "#2A3340" : "#E2E7EE"}` }}>
        Conversa da venda · <b>{venda.cliente}</b> — analistas, corretor e gerente responsáveis
      </div>
      <div style={{ flex: 1, overflowY: "auto", padding: 12, background: bgThread, display: "flex", flexDirection: "column", gap: 8 }}>
        {msgs.length === 0 && <div style={{ color: "#8B99A9", fontSize: 13, textAlign: "center", margin: "auto" }}>Nenhuma mensagem ainda. Comece a conversa.</div>}
        {msgs.map((m) => {
          const meu = m.autor === usuario.nome;
          return (
            <div key={m.id} style={{ display: "flex", flexDirection: "column", alignItems: meu ? "flex-end" : "flex-start" }}>
              <div style={{ maxWidth: "78%", background: meu ? CORES.primary : (dark ? "#222B36" : "#fff"), color: meu ? "#fff" : (dark ? "#E8ECF1" : "#1B2733"), border: meu ? "none" : `1px solid ${dark ? "#2A3340" : "#E2E7EE"}`, borderRadius: 12, padding: "8px 12px", fontSize: 13.5, lineHeight: 1.45, whiteSpace: "pre-wrap", wordBreak: "break-word" }}>
                {m.texto}
              </div>
              <div style={{ fontSize: 10.5, color: "#8B99A9", margin: "3px 4px 0" }}>
                {meu ? "você" : m.autor}{m.autor_papel ? ` · ${m.autor_papel}` : ""} · {fmtData(m.criado_em)}
              </div>
            </div>
          );
        })}
        <div ref={fimRef} />
      </div>
      <div style={{ display: "flex", gap: 8, padding: 10, background: dark ? "#1A222C" : "#fff", borderTop: `1px solid ${dark ? "#2A3340" : "#E2E7EE"}` }}>
        <textarea
          value={texto}
          onChange={(e) => setTexto(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); enviar(); } }}
          placeholder="Escreva uma mensagem…  (Enter envia, Shift+Enter quebra linha)"
          rows={1}
          style={{ ...S.input(dark), flex: 1, resize: "none", fontSize: 13 }}
        />
        <button onClick={enviar} disabled={enviando || !texto.trim()} style={{ ...S.btn(), opacity: enviando || !texto.trim() ? 0.5 : 1 }}>Enviar</button>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------
// INBOX — lista de conversas por venda, com não lidas
// ---------------------------------------------------------------
export default function Inbox({ db, usuario, dark, abrirVenda, salvar, recarregar }) {
  const [soNaoLidas, setSoNaoLidas] = useState(false);
  const [busca, setBusca] = useState("");
  const [aberta, setAberta] = useState(null); // venda selecionada
  const vendas = db.vendas || [];
  const mensagens = db.mensagens || [];

  // agrupa por venda
  const conversas = useMemo(() => {
    const porVenda = {};
    mensagens.forEach((m) => { (porVenda[m.venda_id] = porVenda[m.venda_id] || []).push(m); });
    return Object.entries(porVenda).map(([venda_id, msgs]) => {
      const venda = vendas.find((v) => v.id === venda_id);
      const ordenadas = msgs.slice().sort((a, b) => new Date(b.criado_em) - new Date(a.criado_em));
      const ultima = ordenadas[0];
      const naoLidas = msgs.filter((m) => m.autor !== usuario.nome && String(m.lida).toUpperCase() !== "SIM").length;
      return { venda, venda_id, ultima, naoLidas, total: msgs.length };
    }).filter((c) => c.venda)
      .sort((a, b) => new Date(b.ultima.criado_em) - new Date(a.ultima.criado_em));
  }, [mensagens, vendas, usuario.nome]);

  const lista = conversas
    .filter((c) => !soNaoLidas || c.naoLidas > 0)
    .filter((c) => !busca || [c.venda.cliente, c.venda.empreendimento, c.ultima.texto].some((x) => String(x || "").toLowerCase().includes(busca.toLowerCase())));

  const vendaAberta = aberta ? vendas.find((v) => v.id === aberta.id) || aberta : null;

  return (
    <div style={{ padding: 16 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14, flexWrap: "wrap" }}>
        <h2 style={{ margin: 0, fontSize: 20 }}>Inbox</h2>
        <label style={{ fontSize: 12.5, color: dark ? "#9AA7B6" : "#5B6B7C", display: "flex", alignItems: "center", gap: 5, cursor: "pointer" }}>
          <input type="checkbox" checked={soNaoLidas} onChange={(e) => setSoNaoLidas(e.target.checked)} /> só não lidas
        </label>
        <input value={busca} onChange={(e) => setBusca(e.target.value)} placeholder="Buscar…" style={{ marginLeft: "auto", ...S.input(dark), width: 220 }} />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "minmax(280px, 360px) 1fr", gap: 14, alignItems: "start" }} className="inbox-grid">
        {/* lista de conversas */}
        <div style={{ ...S.card(dark), overflow: "hidden" }}>
          {lista.length === 0 ? (
            <div style={{ padding: 24, textAlign: "center", color: "#8B99A9", fontSize: 13 }}>Nenhuma conversa{soNaoLidas ? " não lida" : ""}.</div>
          ) : lista.map((c) => {
            const ativo = vendaAberta && vendaAberta.id === c.venda_id;
            return (
              <div key={c.venda_id} onClick={() => setAberta(c.venda)} style={{ padding: "11px 13px", borderBottom: `1px solid ${dark ? "#222B36" : "#F0F2F6"}`, cursor: "pointer", background: ativo ? (dark ? "#1E2833" : "#F0F4FA") : "transparent", display: "flex", gap: 10 }}>
                <div style={{ width: 34, height: 34, borderRadius: "50%", background: CORES.primary, color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 700, flexShrink: 0 }}>{iniciais(c.venda.cliente)}</div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                    <span style={{ fontWeight: 700, fontSize: 13, flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{c.venda.cliente}</span>
                    {c.naoLidas > 0 && <span style={{ background: CORES.primary, color: "#fff", fontSize: 10.5, fontWeight: 700, borderRadius: 10, padding: "1px 6px" }}>{c.naoLidas}</span>}
                  </div>
                  <div style={{ fontSize: 11.5, color: "#8B99A9", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                    {c.ultima.autor === usuario.nome ? "você: " : ""}{c.ultima.texto}
                  </div>
                  <div style={{ fontSize: 10.5, color: "#A6B2BF", marginTop: 1 }}>{c.venda.empreendimento || "—"} · {fmtData(c.ultima.criado_em)}</div>
                </div>
              </div>
            );
          })}
        </div>

        {/* conversa selecionada */}
        <div>
          {vendaAberta ? (
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
                <div style={{ fontWeight: 700, fontSize: 15 }}>{vendaAberta.cliente}</div>
                <button onClick={() => abrirVenda(vendaAberta)} style={{ ...S.btn("ghost"), padding: "5px 10px", fontSize: 12 }}>abrir venda ↗</button>
              </div>
              <ChatThread db={db} usuario={usuario} venda={vendaAberta} salvar={salvar} recarregar={recarregar} dark={dark} altura={520} />
            </div>
          ) : (
            <Vazio dark={dark} texto="Selecione uma conversa à esquerda para ler e responder." />
          )}
        </div>
      </div>

      <style>{`@media (max-width:820px){ .inbox-grid{ grid-template-columns: 1fr !important; } }`}</style>
    </div>
  );
}
