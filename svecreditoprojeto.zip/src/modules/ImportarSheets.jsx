import React, { useState } from "react";
import { api } from "../lib/api";
import { S } from "../components/ui";
import { puxarSheet, linhasParaVendas } from "../lib/sheetlink";

// Cola o link de uma planilha Google pública e importa as vendas (só leitura).
export default function ImportarSheets({ dark, avisar, recarregar, compacto }) {
  const [link, setLink] = useState("");
  const [carregando, setCarregando] = useState(false);
  const [status, setStatus] = useState(null); // {ok, msg}

  const puxar = async () => {
    if (!link.trim()) return setStatus({ ok: false, msg: "Cole o link da planilha." });
    setCarregando(true); setStatus({ ok: true, msg: "Lendo a planilha…" });
    try {
      const dados = await puxarSheet(link);
      const { vendas, ignoradas, colunasMapeadas } = linhasParaVendas(dados);
      if (!vendas.length) {
        setCarregando(false);
        setStatus({ ok: false, msg: "Nenhuma linha com nome de cliente foi encontrada. Confira se a 1ª linha da aba tem os títulos das colunas." });
        return;
      }
      let n = 0;
      for (const v of vendas) { await api.salvar("vendas", v, false); n++; }
      const mapeadas = Object.values(colunasMapeadas).length;
      setCarregando(false);
      setStatus({ ok: true, msg: `Importadas ${n} venda(s) (${mapeadas} colunas reconhecidas${ignoradas ? `, ${ignoradas} linha(s) sem cliente ignoradas` : ""}). Recarregando…` });
      avisar && avisar(`${n} venda(s) importada(s)`);
      setTimeout(() => { if (recarregar) recarregar(); else window.location.reload(); }, 1200);
    } catch (e) {
      setCarregando(false);
      setStatus({ ok: false, msg: String(e.message || e) });
    }
  };

  const cor = status ? (status.ok ? "#2E8B57" : "#B03A3A") : "#8B99A9";
  return (
    <div style={{ ...S.card(dark), padding: 16, marginBottom: compacto ? 0 : 16, borderLeft: "4px solid #2456A6" }}>
      <div style={{ fontWeight: 700, fontSize: compacto ? 15 : 18, marginBottom: 4 }}>Puxar do Google Sheets pelo link</div>
      <div style={{ fontSize: 12, color: "#8B99A9", marginBottom: 10, lineHeight: 1.5 }}>
        Cole o link da planilha e clique em <b>Puxar</b>. Importa as vendas da aba do link (a 1ª linha deve ter os títulos das colunas: cliente, cpf, empreendimento, gerente, valor, status…).<br />
        A planilha precisa estar compartilhada como <b>“Qualquer pessoa com o link → Leitor”</b>. Isso <b>lê/importa</b> os dados; não grava de volta no Sheets.
      </div>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "flex-end" }}>
        <div style={{ flex: 1, minWidth: 220 }}>
          <label style={S.label(dark)}>Link da planilha</label>
          <input value={link} onChange={(e) => setLink(e.target.value)} placeholder="https://docs.google.com/spreadsheets/d/…/edit?gid=…" style={S.input(dark)} />
        </div>
        <button onClick={puxar} disabled={carregando} style={{ ...S.btn(), opacity: carregando ? 0.6 : 1 }}>{carregando ? "Puxando…" : "Puxar e importar"}</button>
      </div>
      {status && <div style={{ marginTop: 10, fontSize: 12.5, fontWeight: 600, color: cor }}>{status.msg}</div>}
    </div>
  );
}
