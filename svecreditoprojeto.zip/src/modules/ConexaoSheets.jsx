import React, { useState } from "react";
import { api } from "../lib/api";
import { S } from "../components/ui";

// Painel de conexão ao banco (Supabase ou Google Sheets), salvo no navegador.
// Usado na tela de Login e em Configurações.
export default function ConexaoSheets({ dark, avisar, compacto }) {
  const cfg = api.getConfig();
  const [provider, setProvider] = useState(cfg.provider || "supabase");
  const [sbUrl, setSbUrl] = useState(cfg.sbUrl || "");
  const [sbKey, setSbKey] = useState(cfg.sbKey || "");
  const [url, setUrl] = useState(cfg.url || "");
  const [token, setToken] = useState(cfg.token || "");
  const [status, setStatus] = useState(null);
  const [testando, setTestando] = useState(false);
  const modo = api.modo;
  const conectado = modo === "supabase" || modo === "sheets";

  const conf = () => (provider === "supabase" ? { provider, sbUrl, sbKey } : { provider, url, token });

  const testar = async () => {
    setTestando(true); setStatus(null);
    const r = await api.testar(conf());
    setTestando(false);
    setStatus(r.ok ? { ok: true, msg: `Conexão OK — ${r.total} registro(s).` } : { ok: false, msg: r.error });
  };
  const conectar = async () => {
    setTestando(true); setStatus(null);
    const r = await api.testar(conf());
    setTestando(false);
    if (!r.ok) { setStatus({ ok: false, msg: r.error }); return; }
    api.setConfig(conf());
    avisar && avisar("Conectado");
    setStatus({ ok: true, msg: "Conectado! Recarregando…" });
    setTimeout(() => window.location.reload(), 600);
  };
  const desconectar = () => { api.desconectar(); avisar && avisar("Desconectado — modo demonstração"); setTimeout(() => window.location.reload(), 400); };

  const cor = status ? (status.ok ? "#2E8B57" : "#B03A3A") : "#8B99A9";
  const tab = (id, label) => (
    <button onClick={() => { setProvider(id); setStatus(null); }} style={{ flex: 1, padding: "8px 10px", borderRadius: 8, border: `1px solid ${provider === id ? "#D71920" : (dark ? "#2A3340" : "#D5DBE3")}`, background: provider === id ? "#D71920" : "transparent", color: provider === id ? "#fff" : (dark ? "#E8ECF1" : "#1B2733"), fontWeight: 700, fontSize: 12.5, cursor: "pointer", fontFamily: "inherit" }}>{label}</button>
  );

  return (
    <div style={{ ...S.card(dark), padding: 16, marginBottom: compacto ? 0 : 16, borderLeft: `4px solid ${conectado ? "#2E8B57" : "#C77E1B"}` }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
        <div style={{ fontWeight: 700, fontSize: compacto ? 15 : 18 }}>Banco de dados</div>
        <span style={{ fontSize: 11, fontWeight: 700, padding: "2px 8px", borderRadius: 12, color: "#fff", background: conectado ? "#2E8B57" : "#C77E1B" }}>{modo === "supabase" ? "SUPABASE" : modo === "sheets" ? "GOOGLE SHEETS" : "DEMONSTRAÇÃO"}</span>
      </div>

      <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
        {tab("supabase", "Supabase (fácil)")}
        {tab("sheets", "Google Sheets")}
      </div>

      {provider === "supabase" ? (
        <>
          <div style={{ fontSize: 12, color: "#8B99A9", marginBottom: 10, lineHeight: 1.5 }}>
            Crie um projeto grátis em <b>supabase.com</b>, rode o SQL de <code>api/supabase.sql</code> (SQL Editor → Run) e cole abaixo a URL do projeto e a chave <b>anon public</b> (Project Settings → API).
          </div>
          <div style={{ display: "grid", gap: 8, marginBottom: 10 }}>
            <div><label style={S.label(dark)}>Project URL</label><input value={sbUrl} onChange={(e) => setSbUrl(e.target.value)} placeholder="https://xxxxxxxx.supabase.co" style={S.input(dark)} /></div>
            <div><label style={S.label(dark)}>Anon public key</label><input value={sbKey} onChange={(e) => setSbKey(e.target.value)} placeholder="eyJhbGciOi… (chave anon)" style={S.input(dark)} /></div>
          </div>
        </>
      ) : (
        <>
          <div style={{ fontSize: 12, color: "#8B99A9", marginBottom: 10, lineHeight: 1.5 }}>
            Publique <code>api/apps-script-backend.gs</code> na planilha (Extensões → Apps Script), implante como App da Web com acesso <b>“Qualquer pessoa com o link”</b> e cole a URL <code>/exec</code> + token.
          </div>
          <div style={{ display: "grid", gap: 8, marginBottom: 10 }}>
            <div><label style={S.label(dark)}>URL do Web App (/exec)</label><input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://script.google.com/macros/s/…/exec" style={S.input(dark)} /></div>
            <div><label style={S.label(dark)}>Token</label><input value={token} onChange={(e) => setToken(e.target.value)} placeholder="o mesmo TOKEN do script" style={S.input(dark)} /></div>
          </div>
        </>
      )}

      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        <button onClick={testar} disabled={testando} style={{ ...S.btn("ghost"), opacity: testando ? 0.6 : 1 }}>{testando ? "Testando…" : "Testar conexão"}</button>
        <button onClick={conectar} disabled={testando} style={{ ...S.btn(), opacity: testando ? 0.6 : 1 }}>Conectar e sincronizar</button>
        {conectado && <button onClick={desconectar} style={S.btn("danger")}>Desconectar</button>}
      </div>
      {status && <div style={{ marginTop: 10, fontSize: 12.5, fontWeight: 600, color: cor }}>{status.msg}</div>}
    </div>
  );
}
