import React, { useState, useRef } from "react";
import { DISTRATO_STATUS, distStatusDef, fmtBRL, fmtData, diasParado, uid } from "../lib/defs";
import { Card, S, Vazio } from "../components/ui";

export default function Distratos({ db, dark, salvar, excluir, avisar }) {
  const [aberto, setAberto] = useState(null);
  const [novo, setNovo] = useState(false);
  const dragId = useRef(null);
  const distratos = db.distratos || [];

  const mover = async (id, status) => {
    const d = distratos.find((x) => x.id === id);
    if (!d || d.status === status) return;
    await salvar("distratos", { ...d, status });
    avisar(`Distrato → ${distStatusDef(status).nome}`);
  };

  // dashboard
  const totalDevolvido = distratos.reduce((s, d) => s + (Number(d.valor_devolvido) || 0), 0);
  const motivos = {};
  distratos.forEach((d) => { const m = d.motivo || "—"; motivos[m] = (motivos[m] || 0) + 1; });
  const motivosTop = Object.entries(motivos).sort((a, b) => b[1] - a[1]).slice(0, 5);
  const porEmpreend = {};
  distratos.forEach((d) => { const e = d.empreendimento || "—"; porEmpreend[e] = (porEmpreend[e] || 0) + 1; });

  return (
    <div style={{ padding: 16 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
        <h2 style={{ margin: 0, fontSize: 20 }}>Distratos</h2>
        <button onClick={() => setNovo(true)} style={{ ...S.btn(), marginLeft: "auto" }}>+ Novo distrato</button>
      </div>

      <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 16 }}>
        <Card dark={dark} titulo="Quantidade" valor={distratos.length} cor="#B03A3A" />
        <Card dark={dark} titulo="Valor devolvido" valor={fmtBRL(totalDevolvido)} />
        <Card dark={dark} titulo="Motivo mais comum" valor={motivosTop[0] ? motivosTop[0][0] : "—"} sub={motivosTop[0] ? `${motivosTop[0][1]} casos` : ""} />
      </div>

      {distratos.length === 0 ? (
        <Vazio dark={dark} texto="Nenhum distrato registrado." />
      ) : (
        <div style={{ display: "flex", gap: 12, overflowX: "auto", paddingBottom: 12, alignItems: "flex-start" }}>
          {DISTRATO_STATUS.map((st) => {
            const cards = distratos.filter((d) => d.status === st.id);
            return (
              <div key={st.id} onDragOver={(e) => e.preventDefault()} onDrop={() => { if (dragId.current) mover(dragId.current, st.id); dragId.current = null; }} style={{ minWidth: 210, width: 210, background: dark ? "#161E28" : "#F7F8FA", borderRadius: 10, border: `1px solid ${st.cor}33`, flexShrink: 0 }}>
                <div style={{ padding: "9px 11px", borderBottom: `2px solid ${st.cor}`, display: "flex", alignItems: "center", gap: 6 }}>
                  <span style={{ fontWeight: 700, fontSize: 12 }}>{st.nome}</span>
                  <span style={{ marginLeft: "auto", fontSize: 12, fontWeight: 700, color: st.cor }}>{cards.length}</span>
                </div>
                <div style={{ padding: 8, display: "flex", flexDirection: "column", gap: 8, minHeight: 50 }}>
                  {cards.map((d) => (
                    <div key={d.id} draggable onDragStart={() => (dragId.current = d.id)} onClick={() => setAberto(d)} style={{ background: dark ? "#1E2833" : "#fff", borderRadius: 8, padding: 10, cursor: "grab", border: `1px solid ${dark ? "#2A3340" : "#E2E7EE"}`, color: dark ? "#E8ECF1" : "#1B2733" }}>
                      <div style={{ fontWeight: 700, fontSize: 12.5 }}>{d.cliente || "(sem nome)"}</div>
                      <div style={{ fontSize: 11, color: "#8B99A9" }}>{d.empreendimento || "—"}</div>
                      <div style={{ fontSize: 11.5, marginTop: 3 }}>{d.motivo || "—"}</div>
                      <div style={{ fontSize: 12, fontWeight: 600, marginTop: 2 }}>{fmtBRL(d.valor_devolvido)}</div>
                    </div>
                  ))}
                  {cards.length === 0 && <div style={{ fontSize: 11, color: "#8B99A9", textAlign: "center", padding: 6 }}>vazio</div>}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {(aberto || novo) && (
        <DistratoForm db={db} distrato={aberto} salvar={salvar} excluir={excluir} avisar={avisar} fechar={() => { setAberto(null); setNovo(false); }} />
      )}
    </div>
  );
}

function DistratoForm({ db, distrato, salvar, excluir, avisar, fechar }) {
  const [f, setF] = useState(distrato || { cliente: "", empreendimento: "", motivo: "", data_solicitacao: "", valor_pago: "", valor_devolvido: "", percentual_retencao: "", responsavel: "", status: "D_RECEBIDA", obs: "", documentos: "" });
  const campo = (k, r, tipo = "text") => <div><label style={S.label()}>{r}</label><input type={tipo} value={f[k] || ""} onChange={(e) => setF({ ...f, [k]: e.target.value })} style={S.input()} /></div>;
  const salvarD = async () => { if (!f.cliente.trim()) return avisar("Informe o cliente", true); await salvar("distratos", f); avisar("Distrato salvo"); fechar(); };

  return (
    <div onClick={fechar} style={{ position: "fixed", inset: 0, background: "rgba(15,23,33,.45)", zIndex: 50, display: "flex", justifyContent: "flex-end" }}>
      <div onClick={(e) => e.stopPropagation()} style={{ width: "min(560px,100vw)", background: "#fff", height: "100%", overflowY: "auto", color: "#1B2733" }}>
        <div style={{ padding: "16px 20px", borderBottom: "1px solid #E2E7EE", display: "flex", alignItems: "center" }}>
          <div style={{ fontWeight: 800, fontSize: 17 }}>{distrato ? "Distrato" : "Novo distrato"}</div>
          <button onClick={fechar} style={{ ...S.btn("ghost"), padding: "6px 10px", marginLeft: "auto" }}>✕</button>
        </div>
        <div style={{ padding: 20, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          {campo("cliente", "Cliente")}
          <div><label style={S.label()}>Empreendimento</label><input list="le" value={f.empreendimento || ""} onChange={(e) => setF({ ...f, empreendimento: e.target.value })} style={S.input()} /><datalist id="le">{(db.empreendimentos || []).map((x) => <option key={x.id} value={x.nome} />)}</datalist></div>
          <div><label style={S.label()}>Motivo</label><input list="lm" value={f.motivo || ""} onChange={(e) => setF({ ...f, motivo: e.target.value })} style={S.input()} /><datalist id="lm">{(db.motivos_distrato || []).map((x) => <option key={x.id} value={x.nome} />)}</datalist></div>
          {campo("data_solicitacao", "Data solicitação", "date")}
          {campo("valor_pago", "Valor pago")}{campo("valor_devolvido", "Valor devolvido")}
          {campo("percentual_retencao", "% retenção")}{campo("responsavel", "Responsável")}
          <div><label style={S.label()}>Status</label><select value={f.status} onChange={(e) => setF({ ...f, status: e.target.value })} style={S.input()}>{DISTRATO_STATUS.map((s) => <option key={s.id} value={s.id}>{s.nome}</option>)}</select></div>
          {campo("documentos", "Link documentos")}
          <div style={{ gridColumn: "1 / -1" }}><label style={S.label()}>Observações</label><textarea value={f.obs || ""} onChange={(e) => setF({ ...f, obs: e.target.value })} rows={3} style={{ ...S.input(), resize: "vertical" }} /></div>
          <div style={{ gridColumn: "1 / -1", display: "flex", gap: 8 }}>
            <button onClick={salvarD} style={S.btn()}>Salvar</button>
            {distrato && <button onClick={async () => { if (confirm("Excluir distrato?")) { await excluir("distratos", distrato.id); fechar(); } }} style={S.btn("danger")}>Excluir</button>}
          </div>
        </div>
      </div>
    </div>
  );
}
