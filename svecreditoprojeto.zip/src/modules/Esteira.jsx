import React, { useState, useRef } from "react";
import { ESTAGIOS, ETAPAS, estDef, etapaDe, corEst, fmtBRL, diasParado, iniciais, mascaraCPF } from "../lib/defs";
import { Vazio } from "../components/ui";

export default function Esteira({ db, dark, salvar, registrarHistorico, avisar, abrirVenda, filtroEtapa, titulo }) {
  const [busca, setBusca] = useState("");
  const dragId = useRef(null);
  const vendas = db.vendas || [];

  // se filtroEtapa: mostra só os estágios daquela etapa. Senão (esteira comercial): mostra COMERCIAL + SECRETARIA.
  const etapasMostradas = filtroEtapa ? [filtroEtapa] : ["COMERCIAL", "SECRETARIA"];
  const colunas = ESTAGIOS.filter((e) => etapasMostradas.includes(e.etapa));

  const filtradas = vendas.filter((v) => {
    if (!busca) return true;
    const t = busca.toLowerCase();
    return [v.cliente, v.cpf, v.codigo, v.empreendimento, v.corretor].some((c) => String(c || "").toLowerCase().includes(t));
  });

  const mover = async (vendaId, destino) => {
    const v = vendas.find((x) => x.id === vendaId);
    if (!v || v.estagio === destino) return;
    await registrarHistorico(vendaId, "Mudou de estágio", `${estDef(v.estagio).nome} → ${estDef(destino).nome}`);
    await salvar("vendas", { ...v, estagio: destino, data_estagio: new Date().toISOString() });
    avisar(`Movida para ${estDef(destino).nome}`);
  };

  return (
    <div style={{ padding: 16 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12, flexWrap: "wrap" }}>
        <h2 style={{ margin: 0, fontSize: 20 }}>{titulo}</h2>
        <input value={busca} onChange={(e) => setBusca(e.target.value)} placeholder="Buscar…" style={{ padding: "7px 10px", borderRadius: 6, border: `1px solid ${dark ? "#2A3340" : "#D5DBE3"}`, background: dark ? "#1A222C" : "#fff", color: dark ? "#E8ECF1" : "#1B2733", fontSize: 13, marginLeft: "auto" }} />
        <span style={{ fontSize: 12, color: "#8B99A9" }}>arraste os cartões</span>
      </div>

      {vendas.length === 0 ? (
        <Vazio dark={dark} texto="Nenhuma venda ainda. Cadastre em 'Nova Venda'." />
      ) : (
        <div style={{ display: "flex", gap: 12, overflowX: "auto", paddingBottom: 12, alignItems: "flex-start" }}>
          {colunas.map((est) => {
            const cards = filtradas.filter((v) => v.estagio === est.id);
            const cor = etapaDe(est.id).cor, bg = dark ? "#161E28" : etapaDe(est.id).bg;
            return (
              <div key={est.id} onDragOver={(e) => e.preventDefault()} onDrop={() => { if (dragId.current) mover(dragId.current, est.id); dragId.current = null; }} style={{ minWidth: 230, width: 230, background: bg, borderRadius: 10, border: `1px solid ${cor}33`, flexShrink: 0 }}>
                <div style={{ padding: "9px 11px", display: "flex", alignItems: "center", gap: 7, borderBottom: `2px solid ${cor}` }}>
                  <span style={{ fontWeight: 700, fontSize: 12, lineHeight: 1.2, color: dark ? "#E8ECF1" : "#1B2733" }}>{est.nome}</span>
                  <span style={{ marginLeft: "auto", fontSize: 12, fontWeight: 700, color: cor }}>{cards.length}</span>
                </div>
                <div style={{ padding: 8, display: "flex", flexDirection: "column", gap: 8, minHeight: 50 }}>
                  {cards.map((v) => {
                    const dias = diasParado(v.data_estagio);
                    return (
                      <div key={v.id} draggable onDragStart={() => (dragId.current = v.id)} onClick={() => abrirVenda(v)} style={{ background: dark ? "#1E2833" : "#fff", borderRadius: 8, padding: 10, cursor: "grab", boxShadow: "0 1px 2px rgba(20,30,45,.08)", border: `1px solid ${dark ? "#2A3340" : "#E2E7EE"}`, color: dark ? "#E8ECF1" : "#1B2733" }}>
                        <div style={{ fontWeight: 700, fontSize: 12.5, marginBottom: 2 }}>{v.cliente || "(sem nome)"}</div>
                        <div style={{ fontSize: 11, color: "#8B99A9" }}>{v.empreendimento || "—"}{v.unidade ? ` · ${v.unidade}` : ""}</div>
                        <div style={{ fontSize: 12, fontWeight: 600, margin: "4px 0" }}>{fmtBRL(v.vlr_venda)}</div>
                        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                          {v.corretor && <span title={v.corretor} style={{ width: 20, height: 20, borderRadius: "50%", background: cor, color: "#fff", fontSize: 9, fontWeight: 700, display: "inline-flex", alignItems: "center", justifyContent: "center" }}>{iniciais(v.corretor)}</span>}
                          <span style={{ marginLeft: "auto", fontSize: 10.5, fontWeight: 700, color: dias > 5 ? "#fff" : "#8B99A9", background: dias > 5 ? "#B03A3A" : dias > 3 ? "#C77E1B" : (dark ? "#222B36" : "#EEF1F5"), borderRadius: 10, padding: "2px 7px" }}>{dias}d</span>
                        </div>
                      </div>
                    );
                  })}
                  {cards.length === 0 && <div style={{ fontSize: 11, color: "#8B99A9", textAlign: "center", padding: 6 }}>vazio</div>}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
