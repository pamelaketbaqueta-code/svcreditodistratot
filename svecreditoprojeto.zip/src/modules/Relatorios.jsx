import React, { useState } from "react";
import { estDef, etapaDe, diasParado, fmtBRL } from "../lib/defs";
import { Card, Barras, S } from "../components/ui";

export default function Relatorios({ db, dark }) {
  const vendas = db.vendas || [];
  const distratos = db.distratos || [];
  const pendencias = (db.pendencias || []).filter((p) => p.resolvida !== "SIM" && p.resolvida !== true);
  const [agrupar, setAgrupar] = useState("empreendimento");

  const validadas = vendas.filter((v) => ["A_VALIDADO_CEF", "A_VALIDADO_DIRETO", "E_CONCLUIDO"].includes(v.estagio));
  const conversao = vendas.length ? Math.round((validadas.length / vendas.length) * 100) : 0;
  const ativas = vendas.filter((v) => !["E_CONCLUIDO", "X_CANCELADO", "X_DISTRATO"].includes(v.estagio));
  const tempoMedio = ativas.length ? Math.round(ativas.reduce((s, v) => s + diasParado(v.data_estagio), 0) / ativas.length) : 0;

  const CAMPO = { empreendimento: "empreendimento", corretor: "corretor", gerente: "gerente", diretor: "diretor", banco: "banco", analista: "analista_sv" };
  const grupos = {};
  vendas.forEach((v) => { const chave = v[CAMPO[agrupar]] || "—"; grupos[chave] = (grupos[chave] || 0) + 1; });
  const dadosGrupo = Object.entries(grupos).map(([nome, valor]) => ({ nome, valor })).sort((a, b) => b.valor - a.valor).slice(0, 12);

  const exportarCSV = () => {
    const cols = ["cliente", "cpf", "empreendimento", "unidade", "estagio", "vlr_venda", "corretor", "gerente", "banco"];
    const linhas = [cols.join(";")].concat(vendas.map((v) => cols.map((c) => c === "estagio" ? estDef(v.estagio).nome : `${v[c] ?? ""}`).join(";")));
    const blob = new Blob(["\ufeff" + linhas.join("\n")], { type: "text/csv;charset=utf-8" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "vendas-metrocasa.csv"; a.click();
  };

  return (
    <div style={{ padding: 16 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
        <h2 style={{ margin: 0, fontSize: 20 }}>Relatórios</h2>
        <button onClick={exportarCSV} style={{ ...S.btn("ghost"), marginLeft: "auto" }}>Exportar CSV</button>
      </div>

      <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 18 }}>
        <Card dark={dark} titulo="Conversão" valor={`${conversao}%`} cor="#2E8B57" />
        <Card dark={dark} titulo="Tempo médio" valor={`${tempoMedio}d`} />
        <Card dark={dark} titulo="Vendas validadas" valor={validadas.length} cor="#2E8B57" />
        <Card dark={dark} titulo="Distratos" valor={distratos.length} cor="#B03A3A" />
        <Card dark={dark} titulo="Pendências abertas" valor={pendencias.length} cor="#C77E1B" />
      </div>

      <div style={{ ...S.card(dark), padding: 16 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14, flexWrap: "wrap" }}>
          <span style={{ fontWeight: 700, fontSize: 13 }}>Vendas por</span>
          <select value={agrupar} onChange={(e) => setAgrupar(e.target.value)} style={{ ...S.input(dark), width: 200 }}>
            {Object.keys(CAMPO).map((k) => <option key={k} value={k}>{k[0].toUpperCase() + k.slice(1)}</option>)}
          </select>
        </div>
        <Barras dark={dark} dados={dadosGrupo} />
      </div>
    </div>
  );
}
