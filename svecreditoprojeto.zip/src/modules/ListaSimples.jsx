import React, { useState } from "react";
import { estDef, corEst, bgEst, fmtBRL, fmtData, mascaraCPF, diasParado, parseJSON } from "../lib/defs";
import { S, Vazio } from "../components/ui";

export default function ListaSimples({ db, dark, abrirVenda, tipo }) {
  const [busca, setBusca] = useState("");
  const vendas = db.vendas || [];

  const TITULOS = { validadas: "Validadas", pendencias: "Pendências", clientes: "Clientes", documentos: "Documentos" };

  let linhas = [];
  if (tipo === "validadas") linhas = vendas.filter((v) => ["A_VALIDADO_CEF", "A_VALIDADO_DIRETO", "E_CONCLUIDO"].includes(v.estagio));
  else if (tipo === "clientes") linhas = vendas;
  else if (tipo === "documentos") linhas = vendas;
  // pendências é uma tabela própria

  const filtroTexto = (v) => !busca || [v.cliente, v.cpf, v.codigo, v.empreendimento, v.corretor].some((c) => String(c || "").toLowerCase().includes(busca.toLowerCase()));
  linhas = linhas.filter(filtroTexto);

  return (
    <div style={{ padding: 16 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
        <h2 style={{ margin: 0, fontSize: 20 }}>{TITULOS[tipo]}</h2>
        <input value={busca} onChange={(e) => setBusca(e.target.value)} placeholder="Buscar…" style={{ marginLeft: "auto", padding: "7px 10px", borderRadius: 6, border: `1px solid ${dark ? "#2A3340" : "#D5DBE3"}`, background: dark ? "#1A222C" : "#fff", color: dark ? "#E8ECF1" : "#1B2733", fontSize: 13 }} />
      </div>

      {tipo === "pendencias" ? (
        <TabelaPendencias db={db} dark={dark} abrirVenda={abrirVenda} busca={busca} />
      ) : tipo === "documentos" ? (
        <TabelaDocs linhas={linhas} dark={dark} abrirVenda={abrirVenda} />
      ) : linhas.length === 0 ? (
        <Vazio dark={dark} texto="Nada por aqui." />
      ) : (
        <div style={{ ...S.card(dark), overflow: "hidden" }}>
          <div style={{ overflowX: "auto" }}>
            <table style={{ borderCollapse: "collapse", width: "100%", fontSize: 13, minWidth: 700 }}>
              <thead><tr style={{ background: dark ? "#161E28" : "#F0F2F6", textAlign: "left", color: "#8B99A9", fontSize: 11 }}>
                {["Cliente", tipo === "clientes" ? "Contato" : "Empreend.", "Estágio", "Valor", "Corretor", ""].map((h) => <th key={h} style={{ padding: "8px 10px", textTransform: "uppercase", whiteSpace: "nowrap" }}>{h}</th>)}
              </tr></thead>
              <tbody>
                {linhas.map((v) => (
                  <tr key={v.id} onClick={() => abrirVenda(v)} style={{ cursor: "pointer", borderTop: `1px solid ${dark ? "#222B36" : "#F0F2F6"}` }}>
                    <td style={{ padding: "8px 10px", fontWeight: 600 }}>{v.cliente}<div style={{ fontSize: 10.5, color: "#8B99A9", fontWeight: 400 }}>CPF {mascaraCPF(v.cpf)}</div></td>
                    <td style={{ padding: "8px 10px", color: "#8B99A9", whiteSpace: "nowrap" }}>{tipo === "clientes" ? (v.telefone || v.email || "—") : (v.empreendimento || "—")}</td>
                    <td style={{ padding: "8px 10px", whiteSpace: "nowrap" }}><span style={{ fontSize: 11, fontWeight: 700, color: corEst(v.estagio), background: bgEst(v.estagio), borderRadius: 5, padding: "2px 7px" }}>{estDef(v.estagio).nome}</span></td>
                    <td style={{ padding: "8px 10px", whiteSpace: "nowrap" }}>{fmtBRL(v.vlr_venda)}</td>
                    <td style={{ padding: "8px 10px", whiteSpace: "nowrap" }}>{v.corretor || "—"}</td>
                    <td style={{ padding: "8px 10px", color: "#D71920", fontWeight: 600 }}>abrir →</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

function TabelaPendencias({ db, dark, abrirVenda, busca }) {
  const vendas = db.vendas || [];
  let pend = (db.pendencias || []).filter((p) => p.resolvida !== "SIM" && p.resolvida !== true);
  if (busca) pend = pend.filter((p) => String(p.descricao || "").toLowerCase().includes(busca.toLowerCase()));
  if (pend.length === 0) return <Vazio dark={dark} texto="Nenhuma pendência aberta." />;
  return (
    <div style={{ ...S.card(dark), overflow: "hidden" }}>
      <div style={{ overflowX: "auto" }}>
        <table style={{ borderCollapse: "collapse", width: "100%", fontSize: 13, minWidth: 640 }}>
          <thead><tr style={{ background: dark ? "#161E28" : "#F0F2F6", textAlign: "left", color: "#8B99A9", fontSize: 11 }}>{["Cliente", "Tipo", "Pendência", "Responsável", "Data", ""].map((h) => <th key={h} style={{ padding: "8px 10px", textTransform: "uppercase" }}>{h}</th>)}</tr></thead>
          <tbody>
            {pend.map((p) => {
              const v = vendas.find((x) => x.id === p.venda_id);
              return (
                <tr key={p.id} onClick={() => v && abrirVenda(v)} style={{ cursor: v ? "pointer" : "default", borderTop: `1px solid ${dark ? "#222B36" : "#F0F2F6"}` }}>
                  <td style={{ padding: "8px 10px", fontWeight: 600 }}>{v ? v.cliente : "—"}</td>
                  <td style={{ padding: "8px 10px" }}>{p.tipo || "—"}</td>
                  <td style={{ padding: "8px 10px" }}>{p.descricao}</td>
                  <td style={{ padding: "8px 10px" }}>{p.responsavel || "—"}</td>
                  <td style={{ padding: "8px 10px", whiteSpace: "nowrap" }}>{fmtData(p.criado_em)}</td>
                  <td style={{ padding: "8px 10px", color: "#D71920", fontWeight: 600 }}>{v ? "abrir →" : ""}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function TabelaDocs({ linhas, dark, abrirVenda }) {
  if (linhas.length === 0) return <Vazio dark={dark} texto="Nenhuma venda." />;
  return (
    <div style={{ ...S.card(dark), overflow: "hidden" }}>
      <div style={{ overflowX: "auto" }}>
        <table style={{ borderCollapse: "collapse", width: "100%", fontSize: 13, minWidth: 600 }}>
          <thead><tr style={{ background: dark ? "#161E28" : "#F0F2F6", textAlign: "left", color: "#8B99A9", fontSize: 11 }}>{["Cliente", "Empreend.", "Docs anexados", ""].map((h) => <th key={h} style={{ padding: "8px 10px", textTransform: "uppercase" }}>{h}</th>)}</tr></thead>
          <tbody>
            {linhas.map((v) => {
              const docs = parseJSON(v.documentos, {});
              const n = Object.keys(docs).filter((k) => docs[k]).length;
              return (
                <tr key={v.id} onClick={() => abrirVenda(v)} style={{ cursor: "pointer", borderTop: `1px solid ${dark ? "#222B36" : "#F0F2F6"}` }}>
                  <td style={{ padding: "8px 10px", fontWeight: 600 }}>{v.cliente}</td>
                  <td style={{ padding: "8px 10px", color: "#8B99A9" }}>{v.empreendimento || "—"}</td>
                  <td style={{ padding: "8px 10px" }}>{n} documento(s)</td>
                  <td style={{ padding: "8px 10px", color: "#D71920", fontWeight: 600 }}>abrir →</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
