import React, { useState, useEffect } from "react";
import { ESTAGIOS, ETAPAS, estDef, corEst, CHECK_SV, CHECK_CREDITO, CHECK_STATUS, CHECK_LABEL, CHECK_COLOR, novoChecklist, DOCS_TIPOS, fmtBRL, fmtData, mascaraCPF, diasParado, parseJSON, uid } from "../lib/defs";
import { api } from "../lib/api";
import { S } from "../components/ui";
import { ChatThread } from "./Chat";

export default function DetalheVenda({ venda, db, usuario, dark, salvar, excluir, registrarHistorico, avisar, fechar, recarregar }) {
  const [aba, setAba] = useState("dados");
  const [form, setForm] = useState(venda);
  const [novaPend, setNovaPend] = useState({ tipo: "", descricao: "" });
  const [ia, setIa] = useState(null);
  const [iaLoad, setIaLoad] = useState(false);
  useEffect(() => setForm(venda), [venda.id]);

  const chkSV = parseJSON(venda.checklist_sv, novoChecklist(CHECK_SV));
  const chkCR = parseJSON(venda.checklist_credito, novoChecklist(CHECK_CREDITO));
  const docs = parseJSON(venda.documentos, {});
  const pendVenda = (db.pendencias || []).filter((p) => p.venda_id === venda.id);
  const msgVenda = (db.mensagens || []).filter((m) => m.venda_id === venda.id);
  const msgNaoLidas = msgVenda.filter((m) => m.autor !== usuario.nome && String(m.lida).toUpperCase() !== "SIM").length;
  const histVenda = (db.historico || []).filter((h) => h.venda_id === venda.id).sort((a, b) => new Date(b.criado_em) - new Date(a.criado_em));

  const progresso = (chk, lista) => { const ok = lista.filter(([k]) => ["OK", "NA"].includes(chk[k]?.status)).length; return { ok, total: lista.length }; };

  const setCheck = async (campo, lista, chave, prop, valor, rotulo) => {
    const chk = campo === "checklist_sv" ? { ...chkSV } : { ...chkCR };
    chk[chave] = { ...(chk[chave] || { status: "PENDENTE", obs: "" }), [prop]: valor, quem: usuario.nome, quando: new Date().toISOString() };
    await salvar("vendas", { ...venda, [campo]: JSON.stringify(chk) });
    if (prop === "status") await registrarHistorico(venda.id, "Checklist", `${rotulo}: ${CHECK_LABEL[valor]}`);
  };

  const salvarDocs = async (tipo, link) => {
    const d = { ...docs, [tipo]: link };
    await salvar("vendas", { ...venda, documentos: JSON.stringify(d) });
  };

  const addPendencia = async () => {
    if (!novaPend.descricao.trim()) return;
    await salvar("pendencias", { venda_id: venda.id, tipo: novaPend.tipo, descricao: novaPend.descricao.trim(), responsavel: usuario.nome, status: "ABERTA", comentario: "", resolvida: "NAO", criado_em: new Date().toISOString() });
    await registrarHistorico(venda.id, "Pendência criada", novaPend.descricao.trim());
    setNovaPend({ tipo: "", descricao: "" });
    avisar("Pendência adicionada");
  };
  const togglePend = async (p, resolvida) => {
    await salvar("pendencias", { ...p, resolvida: resolvida ? "SIM" : "NAO", status: resolvida ? "RESOLVIDA" : "ABERTA", resolvida_em: resolvida ? new Date().toISOString() : "" });
    await registrarHistorico(venda.id, resolvida ? "Pendência resolvida" : "Pendência reaberta", p.descricao);
  };

  const analisarIA = async () => {
    setIaLoad(true); setIa(null);
    try {
      const payload = { venda: { ...venda, checklist_sv: undefined, checklist_credito: undefined, documentos: undefined }, checklist_sv: chkSV, checklist_credito: chkCR, pendencias: pendVenda.map((p) => p.descricao), documentos_anexados: Object.keys(docs).filter((k) => docs[k]) };
      const data = await api.ia(payload);
      if (data.erro) { avisar("IA: " + data.erro, true); setIaLoad(false); return; }
      const texto = (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("\n");
      setIa(JSON.parse(texto.replace(/```json|```/g, "").trim()));
    } catch { avisar("Falha na análise de IA", true); }
    setIaLoad(false);
  };
  const corRisco = { baixo: "#2E8B57", medio: "#C77E1B", alto: "#B03A3A" };

  const moverEstagio = async (destino) => {
    await registrarHistorico(venda.id, "Mudou de estágio", `${estDef(venda.estagio).nome} → ${estDef(destino).nome}`);
    await salvar("vendas", { ...venda, estagio: destino, data_estagio: new Date().toISOString() });
  };

  const campo = (k, rotulo) => (
    <div><label style={S.label()}>{rotulo}</label><input value={form[k] || ""} onChange={(e) => setForm({ ...form, [k]: e.target.value })} style={S.input()} /></div>
  );

  const ABAS = [
    ["dados", "Dados Gerais"],
    ["sv", `SV ${progresso(chkSV, CHECK_SV).ok}/${CHECK_SV.length}`],
    ["credito", `Crédito ${progresso(chkCR, CHECK_CREDITO).ok}/${CHECK_CREDITO.length}`],
    ["pend", `Pendências (${pendVenda.filter((p) => p.resolvida !== "SIM" && p.resolvida !== true).length})`],
    ["chat", `Chat${msgNaoLidas ? ` (${msgNaoLidas})` : ""}`],
    ["docs", "Documentos"],
    ["ia", "IA"],
    ["hist", "Histórico"],
  ];

  const ChkBloco = ({ chk, lista, campo: campoChk }) => (
    <div>
      <div style={{ height: 8, background: "#EEF1F5", borderRadius: 4, marginBottom: 12, overflow: "hidden" }}>
        <div style={{ width: `${(progresso(chk, lista).ok / lista.length) * 100}%`, height: "100%", background: "#2E8B57" }} />
      </div>
      {lista.map(([k, rot]) => {
        const item = chk[k] || { status: "PENDENTE", obs: "" };
        return (
          <div key={k} style={{ border: "1px solid #E2E7EE", borderLeft: `4px solid ${CHECK_COLOR[item.status]}`, borderRadius: 7, padding: "9px 11px", marginBottom: 7 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
              <span style={{ fontSize: 13, fontWeight: 600, flex: 1, minWidth: 140 }}>{rot}</span>
              <div style={{ display: "flex", gap: 3 }}>
                {CHECK_STATUS.map((st) => (
                  <button key={st} onClick={() => setCheck(campoChk, lista, k, "status", st, rot)} style={{ padding: "3px 8px", fontSize: 11, fontWeight: 700, borderRadius: 5, cursor: "pointer", border: `1px solid ${item.status === st ? CHECK_COLOR[st] : "#D5DBE3"}`, background: item.status === st ? CHECK_COLOR[st] : "#fff", color: item.status === st ? "#fff" : "#5B6B7C" }}>{CHECK_LABEL[st]}</button>
                ))}
              </div>
            </div>
            <input placeholder="Observação…" defaultValue={item.obs || ""} onBlur={(e) => e.target.value !== (item.obs || "") && setCheck(campoChk, lista, k, "obs", e.target.value, rot)} style={{ ...S.input(), marginTop: 7, fontSize: 12, padding: "6px 8px" }} />
            {item.quem && <div style={{ fontSize: 10.5, color: "#8B99A9", marginTop: 4 }}>por {item.quem} · {fmtData(item.quando)}</div>}
          </div>
        );
      })}
    </div>
  );

  return (
    <div onClick={fechar} style={{ position: "fixed", inset: 0, background: "rgba(15,23,33,.45)", zIndex: 50, display: "flex", justifyContent: "flex-end" }}>
      <div onClick={(e) => e.stopPropagation()} style={{ width: "min(620px,100vw)", background: "#fff", height: "100%", overflowY: "auto", boxShadow: "-6px 0 24px rgba(0,0,0,.2)", color: "#1B2733" }}>
        <div style={{ padding: "16px 20px", borderBottom: "1px solid #E2E7EE", position: "sticky", top: 0, background: "#fff", zIndex: 2 }}>
          <div style={{ display: "flex", alignItems: "flex-start", gap: 10 }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 800, fontSize: 17 }}>{venda.cliente || "(sem nome)"}</div>
              <div style={{ fontSize: 12, color: "#5B6B7C", marginTop: 2 }}>{venda.empreendimento || "—"}{venda.unidade ? ` · ${venda.unidade}` : ""} · CPF {mascaraCPF(venda.cpf)}</div>
              {venda.link && <a href={venda.link} target="_blank" rel="noreferrer" style={{ fontSize: 12, color: "#D71920", fontWeight: 600 }}>abrir pasta ↗</a>}
            </div>
            <button onClick={fechar} style={{ ...S.btn("ghost"), padding: "6px 10px" }}>✕</button>
          </div>
          <div style={{ display: "flex", gap: 8, marginTop: 10, alignItems: "center", flexWrap: "wrap" }}>
            <select value={venda.estagio} onChange={(e) => moverEstagio(e.target.value)} style={{ ...S.input(), width: 250, borderLeft: `4px solid ${corEst(venda.estagio)}` }}>
              {Object.keys(ETAPAS).map((et) => <optgroup key={et} label={ETAPAS[et].nome}>{ESTAGIOS.filter((e) => e.etapa === et).map((e) => <option key={e.id} value={e.id}>{e.nome}</option>)}</optgroup>)}
            </select>
            <span style={{ fontSize: 11.5, color: "#5B6B7C" }}>{diasParado(venda.data_estagio)}d nesta fase</span>
          </div>
          <div style={{ display: "flex", gap: 4, marginTop: 12, flexWrap: "wrap" }}>
            {ABAS.map(([id, nome]) => <button key={id} onClick={() => setAba(id)} style={{ padding: "7px 10px", borderRadius: 6, border: "none", cursor: "pointer", fontSize: 12, fontWeight: 600, background: aba === id ? "#1B2733" : "#EEF1F5", color: aba === id ? "#fff" : "#1B2733" }}>{nome}</button>)}
          </div>
        </div>

        <div style={{ padding: 20 }}>
          {aba === "dados" && (
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              {campo("cliente", "Cliente")}{campo("cpf", "CPF")}{campo("telefone", "Telefone")}{campo("email", "E-mail")}
              {campo("corretor", "Corretor")}{campo("gerente", "Gerente")}{campo("diretor", "Diretor")}{campo("empreendimento", "Empreendimento")}
              {campo("unidade", "Unidade")}{campo("tipologia", "Tipologia")}{campo("renda", "Renda")}{campo("vlr_venda", "Valor venda")}
              {campo("vlr_avaliacao", "Valor avaliação")}{campo("banco", "Banco")}{campo("repasse", "Repasse")}{campo("categoria", "Categoria")}
              {campo("sicaq", "SICAQ")}{campo("data_contrato", "Data contrato")}{campo("link", "Link da pasta")}{campo("codigo", "Chave/Código")}
              <div style={{ gridColumn: "1 / -1" }}><label style={S.label()}>Observações</label><textarea value={form.obs || ""} onChange={(e) => setForm({ ...form, obs: e.target.value })} rows={2} style={{ ...S.input(), resize: "vertical" }} /></div>
              <div style={{ gridColumn: "1 / -1", display: "flex", gap: 8 }}>
                <button onClick={async () => { await salvar("vendas", { ...venda, ...form }); await registrarHistorico(venda.id, "Dados editados", ""); avisar("Salvo"); }} style={S.btn()}>Salvar dados</button>
                <button onClick={async () => { if (confirm("Excluir esta venda?")) { await excluir("vendas", venda.id); fechar(); } }} style={S.btn("danger")}>Excluir</button>
              </div>
            </div>
          )}
          {aba === "sv" && <ChkBloco chk={chkSV} lista={CHECK_SV} campo="checklist_sv" />}
          {aba === "credito" && <ChkBloco chk={chkCR} lista={CHECK_CREDITO} campo="checklist_credito" />}

          {aba === "pend" && (
            <div>
              <div style={{ display: "flex", gap: 8, marginBottom: 14, flexWrap: "wrap" }}>
                <select value={novaPend.tipo} onChange={(e) => setNovaPend({ ...novaPend, tipo: e.target.value })} style={{ ...S.input(), width: 150 }}>
                  <option value="">Tipo…</option>
                  {(db.tipos_pendencia || []).map((t) => <option key={t.id} value={t.nome}>{t.nome}</option>)}
                  <option value="Outro">Outro</option>
                </select>
                <input placeholder="Descrição da pendência…" value={novaPend.descricao} onChange={(e) => setNovaPend({ ...novaPend, descricao: e.target.value })} style={{ ...S.input(), flex: 1, minWidth: 160 }} />
                <button onClick={addPendencia} style={S.btn()}>Adicionar</button>
              </div>
              {pendVenda.length === 0 && <div style={{ color: "#8B99A9", fontSize: 13 }}>Sem pendências.</div>}
              {pendVenda.map((p) => {
                const res = p.resolvida === "SIM" || p.resolvida === true;
                return (
                  <label key={p.id} style={{ display: "flex", gap: 10, alignItems: "flex-start", padding: "9px 11px", border: "1px solid #E2E7EE", borderRadius: 7, marginBottom: 7, cursor: "pointer", background: res ? "#F6F8F7" : "#fff" }}>
                    <input type="checkbox" checked={res} onChange={(e) => togglePend(p, e.target.checked)} style={{ marginTop: 3 }} />
                    <div><div style={{ fontSize: 13, textDecoration: res ? "line-through" : "none", color: res ? "#8B99A9" : "#1B2733" }}>{p.tipo ? `[${p.tipo}] ` : ""}{p.descricao}</div><div style={{ fontSize: 10.5, color: "#8B99A9" }}>{p.responsavel} · {fmtData(p.criado_em)}</div></div>
                  </label>
                );
              })}
            </div>
          )}

          {aba === "chat" && (
            <ChatThread db={db} usuario={usuario} venda={venda} salvar={salvar} recarregar={recarregar} dark={dark} altura={460} />
          )}

          {aba === "docs" && (
            <div>
              <p style={{ fontSize: 12.5, color: "#5B6B7C", marginTop: 0 }}>Cole o link de cada documento (Google Drive). Para upload com arquivo físico, é preciso o backend com armazenamento.</p>
              {DOCS_TIPOS.map((tipo) => (
                <div key={tipo} style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 8 }}>
                  <span style={{ width: 120, fontSize: 13, fontWeight: 600 }}>{tipo}</span>
                  <input defaultValue={docs[tipo] || ""} onBlur={(e) => e.target.value !== (docs[tipo] || "") && salvarDocs(tipo, e.target.value)} placeholder="link…" style={{ ...S.input(), flex: 1, fontSize: 12 }} />
                  {docs[tipo] && <a href={docs[tipo]} target="_blank" rel="noreferrer" style={{ fontSize: 12, color: "#D71920", fontWeight: 600 }}>abrir</a>}
                </div>
              ))}
            </div>
          )}

          {aba === "ia" && (
            <div>
              <p style={{ fontSize: 13, color: "#5B6B7C", marginTop: 0 }}>Análise automática de risco com base nos dados, checklists e documentos.</p>
              <button onClick={analisarIA} disabled={iaLoad} style={{ ...S.btn(), opacity: iaLoad ? 0.6 : 1 }}>{iaLoad ? "Analisando…" : "Analisar com IA"}</button>
              {ia && (
                <div style={{ marginTop: 16, border: "1px solid #E2E7EE", borderRadius: 10, padding: 16 }}>
                  <div style={{ display: "inline-block", padding: "4px 12px", borderRadius: 14, fontWeight: 800, fontSize: 12, textTransform: "uppercase", color: "#fff", background: corRisco[ia.risco] || "#5B6B7C", marginBottom: 10 }}>Risco {ia.risco}</div>
                  <p style={{ fontSize: 13.5, lineHeight: 1.55, marginTop: 0 }}>{ia.resumo}</p>
                  {(ia.pendencias_provaveis || []).length > 0 && (
                    <div>
                      <div style={{ fontWeight: 700, fontSize: 12, textTransform: "uppercase", color: "#5B6B7C", margin: "10px 0 6px" }}>Pendências prováveis</div>
                      {ia.pendencias_provaveis.map((p, i) => (
                        <div key={i} style={{ display: "flex", gap: 8, alignItems: "center", padding: "7px 0", borderTop: "1px solid #EEF1F5", fontSize: 13 }}>
                          <span style={{ flex: 1 }}>{p}</span>
                          <button onClick={async () => { await salvar("pendencias", { venda_id: venda.id, tipo: "IA", descricao: p, responsavel: usuario.nome, status: "ABERTA", resolvida: "NAO", criado_em: new Date().toISOString() }); avisar("Adicionada"); }} style={{ ...S.btn("ghost"), padding: "4px 9px", fontSize: 11.5 }}>+ Pendência</button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {aba === "hist" && (
            <div>
              {histVenda.length === 0 && <div style={{ color: "#8B99A9", fontSize: 13 }}>Sem eventos.</div>}
              {histVenda.map((h) => (
                <div key={h.id} style={{ display: "flex", gap: 10, padding: "9px 0", borderBottom: "1px solid #EEF1F5" }}>
                  <div style={{ width: 8, height: 8, borderRadius: "50%", background: "#D71920", marginTop: 5, flexShrink: 0 }} />
                  <div><div style={{ fontSize: 13 }}>{h.acao}{h.detalhe ? `: ${h.detalhe}` : ""}</div><div style={{ fontSize: 11, color: "#8B99A9" }}>{h.usuario} · {fmtData(h.criado_em)}</div></div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
