# Ligar o sistema à sua planilha do Google Sheets

Isto conecta o CRM ao Google Sheets: dados reais, sincronização nos dois sentidos e login por usuário. Leva ~10 min e **não precisa recompilar o app** — a conexão é feita dentro do próprio sistema.

## Parte 1 — Publicar o script na SUA planilha

1. Abra a sua planilha no Google Sheets.
2. **Extensões → Apps Script**. Vai abrir o editor de script já ligado a essa planilha.
3. Apague o conteúdo do `Code.gs` e **cole todo o arquivo** `apps-script-backend.gs` (está nesta pasta).
4. Na primeira linha, troque o token:
   ```js
   const TOKEN = 'TROQUE-ESTE-TOKEN';   // ex.: 'metrocasa2026@vendas'
   ```
   Guarde esse valor — ele funciona como senha da API.
5. No topo do editor, selecione a função **`instalar`** e clique em **Executar**. Autorize as permissões que o Google pedir (é a sua própria conta).
   - Isso cria as abas: `vendas`, `distratos`, `pendencias`, `historico`, `mensagens`, `corretores`, `gerentes`, `superintendentes`, `diretores`, `analistas`, `empreendimentos`, `bancos`, `motivos_distrato`, `tipos_pendencia`, `usuarios`.
   - E cria um admin: **admin@metrocasa.com** / senha **metrocasa** (troque depois na aba `usuarios`).
   > As abas que você já tinha na planilha continuam intactas — o script só adiciona as que faltam.
6. **Implantar → Nova implantação → tipo App da Web**:
   - **Executar como:** Você (seu e-mail)
   - **Quem pode acessar:** **Qualquer pessoa com o link**  ← passo mais importante
7. Copie a **URL do Web App** (termina em **`/exec`**).
8. (Opcional) Teste no navegador, abrindo:
   `SUA_URL/exec?token=SEU_TOKEN&action=all`
   Tem que aparecer `{"ok":true,"data":{…}}`.

## Parte 2 — Conectar no app (sem recompilar)

Abra o sistema. Na **tela de login**, clique em **“⚙ Conectar Google Sheets”** (ou, já logado como admin, vá em **Configurações → Conexão com Google Sheets**). Então:

1. Cole a **URL /exec** e o **Token**.
2. Clique **Testar conexão**. Deve dizer “Conexão OK”.
3. Clique **Conectar e sincronizar**. O app recarrega já lendo/gravando na planilha.
4. Faça login com **admin@metrocasa.com / metrocasa** (ou um usuário que você criar na aba `usuarios`).

A conexão fica salva no navegador. Para voltar ao modo demonstração, use **Desconectar**.

## Quem pode entrar (aba `usuarios`, coluna `perfil`)

`ADMIN`, `DIRETOR` (Diretor de Vendas), `SUPERINTENDENTE`, `GERENTE` (Gerente de Vendas),
`GERENTE_SV`, `COORD_SV`, `ANALISTA_SV`, `GERENTE_CREDITO`, `COORD_CREDITO`, `ANALISTA_CREDITO`.

Qualquer outro perfil recebe “sem acesso”. Cada um vê só as vendas que lhe cabem:
- **Gerente** → só as vendas dele (onde o **apelido** dele, ou CPF/e-mail, aparece na venda).
- **Superintendente / Diretor** → as vendas da equipe (gerentes abaixo, pelas colunas `superintendente`/`diretor` da aba `gerentes`).
- **Analista de SV / Crédito** → as atribuídas a ele (colunas `analista_sv` / `analista_credito` da venda).
- **Coordenador/Gerente de área e Admin** → todas.

> **Dono da venda:** na aba `vendas`, a coluna `gerente` deve conter o **apelido** do gerente (o mesmo que está na aba `gerentes`). Também vale casar por CPF ou e-mail.

## Problemas comuns

| Sintoma | Causa / solução |
|---|---|
| “A implantação está privada” | Reimplante com **Quem pode acessar: Qualquer pessoa com o link**. |
| “A URL deve terminar em /exec” | Você colou a URL do editor ou a `/dev`. Use a `/exec` da implantação. |
| “Token não confere” | O token do app tem que ser **igual** ao `const TOKEN` do script. |
| “Respondeu, mas não em JSON” | Faltou colar o script certo ou reimplantar. Use **Gerenciar implantações → editar (lápis) → Nova versão** para manter a mesma URL. |
| Editei o script e parou | Toda edição precisa de **Nova versão** na mesma implantação. |
