-- ============================================================
-- METROCASA — Banco de dados (Supabase / Postgres)
-- Cole tudo isto no Supabase: SQL Editor → New query → Run.
-- Cria todas as tabelas do CRM e um usuário admin.
-- ============================================================

create table if not exists vendas (
  id text primary key,
  codigo text, processo text, link text, cliente text, cpf text, telefone text, email text,
  empreendimento text, unidade text, tipologia text, renda text, vlr_venda text, vlr_avaliacao text,
  banco text, repasse text, categoria text, sicaq text, data_contrato text,
  corretor text, gerente text, diretor text, analista_sv text, analista_credito text, assistente text,
  estagio text, data_estagio text, obs text, checklist_sv text, checklist_credito text, documentos text,
  criado_em text, atualizado_em text
);

create table if not exists distratos (
  id text primary key, venda_id text, cliente text, empreendimento text, motivo text,
  data_solicitacao text, valor_pago text, valor_devolvido text, percentual_retencao text,
  responsavel text, status text, obs text, documentos text, criado_em text, atualizado_em text
);

create table if not exists pendencias (
  id text primary key, venda_id text, tipo text, descricao text, responsavel text,
  status text, comentario text, resolvida text, criado_em text, resolvida_em text
);

create table if not exists historico (
  id text primary key, venda_id text, usuario text, papel text, acao text, detalhe text, criado_em text
);

create table if not exists mensagens (
  id text primary key, venda_id text, autor text, autor_papel text, para text, texto text, lida text, criado_em text
);

create table if not exists corretores (
  id text primary key, nome text, telefone text, email text, gerente text, ativo text
);

create table if not exists gerentes (
  id text primary key, nome text, apelido text, cpf text, email text, superintendente text, diretor text, ativo text
);

create table if not exists superintendentes (
  id text primary key, nome text, apelido text, cpf text, email text, diretor text, ativo text
);

create table if not exists diretores (
  id text primary key, nome text, apelido text, cpf text, email text, ativo text
);

create table if not exists analistas (
  id text primary key, nome text, apelido text, cpf text, email text, area text, ativo text
);

create table if not exists empreendimentos (
  id text primary key, nome text, cidade text, tipologia text, total_unidades text, ativo text
);

create table if not exists bancos           ( id text primary key, nome text, ativo text );
create table if not exists motivos_distrato ( id text primary key, nome text, ativo text );
create table if not exists tipos_pendencia  ( id text primary key, nome text, ativo text );

create table if not exists usuarios (
  id text primary key, nome text, apelido text, cpf text, email text, senha text, perfil text, ativo text
);

-- Acesso pela chave anon (ferramenta interna). Para reforçar depois, ative RLS
-- e crie políticas por perfil.
grant usage on schema public to anon, authenticated;
grant all privileges on all tables in schema public to anon, authenticated;
alter default privileges in schema public grant all on tables to anon, authenticated;

-- usuário admin inicial (troque a senha depois)
insert into usuarios (id, nome, apelido, cpf, email, senha, perfil, ativo)
values ('u1', 'Administrador', 'admin', '', 'admin@metrocasa.com', 'metrocasa', 'ADMIN', 'SIM')
on conflict (id) do nothing;
