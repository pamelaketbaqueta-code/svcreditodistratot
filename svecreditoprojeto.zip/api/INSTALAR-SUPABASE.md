# Ligar o sistema a um banco Supabase (jeito mais fácil)

Sem deploy de código e sem os problemas de CORS do Google Sheets. ~5 min.

## Passos

1. Acesse **https://supabase.com** e crie uma conta (pode entrar com o Google).
2. **New project**. Dê um nome, defina uma senha do banco (guarde) e crie. Espere ~1 min ficar pronto.
3. No menu lateral, abra **SQL Editor → New query**. Cole **todo** o conteúdo de `api/supabase.sql` e clique **Run**. Isso cria todas as tabelas e o admin.
4. Vá em **Project Settings → API** e copie dois valores:
   - **Project URL** — algo como `https://xxxxxxxx.supabase.co`
   - **anon public** (em *Project API keys*) — a chave que começa com `eyJ...`
5. Abra o app (`metrocasa-crm.html`). Na tela de login, clique **“⚙ Conectar banco de dados”**, escolha a aba **Supabase**, cole a **Project URL** e a **anon public**, clique **Testar conexão** e depois **Conectar e sincronizar**.
6. Faça login com **admin@metrocasa.com** / **metrocasa** (troque depois em Configurações → Usuários).

Pronto: tudo passa a ler e gravar no Supabase, de qualquer computador.

## Segurança

A chave **anon public** é feita para ficar no navegador. Neste modelo, ela dá
acesso de leitura/escrita às tabelas (ferramenta interna). Para reforçar depois:
no Supabase, ative **RLS** (Row Level Security) nas tabelas e crie políticas por
perfil. Enquanto for uso interno da equipe, pode deixar como está.

## Cadastro da equipe (para o filtro por dono funcionar)

Depois de conectar, entre como admin e vá em **Configurações**:
- Cadastre **Diretores**, **Superintendentes** e **Gerentes** (com **apelido** e, se quiser, CPF/e-mail).
- Em **Gerentes**, preencha `superintendente` e `diretor` de cada um (define a hierarquia).
- Crie os **Usuários** de acesso (aba Usuários), com o mesmo **apelido** do cadastro.

Na venda, a coluna **gerente** deve conter o **apelido** do gerente-dono — é assim
que cada gerente vê só as vendas dele; superintendente/diretor veem a equipe.

## Problemas comuns

| Mensagem | Solução |
|---|---|
| “faltam as tabelas” | Rode o `api/supabase.sql` no SQL Editor. |
| “Chave anon inválida” | Copie a **anon public** (não a service_role) em Settings → API. |
| “URL deve ser …supabase.co” | Use a **Project URL**, não a URL do painel. |
